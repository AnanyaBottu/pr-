# staticSquare
A static square made using Matter.js physics engine
